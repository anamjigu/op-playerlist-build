# OP Player List (Fabric 1.21.11)

`/playerlist` is restricted to operators. A private centered screen lists every online player, provides a search field and pages of six rows, draws online player heads, and displays dimension, block coordinates and this world's cumulative PLAY_TIME statistic in hours and minutes. TP requests are checked by the server on receipt, including OP permission and live player identity.

## Build

Java 21 and Gradle 9.2: `gradle build`. The installable JAR will be `build/libs/op-playerlist-1.0.0.jar`. Alternatively upload the **contents** of this folder to a GitHub repository and run the included Actions workflow. Download the produced artifact; unzip the artifact to get the JAR.

## Install

Install the built JAR and Fabric API on both the Fabric 1.21.11 server and every admin's Fabric 1.21.11 client. Restart the server and client. Other players need no client mod to be listed. OP users enter `/playerlist`. Page arrows and search narrow results; clicking a name displays its details, and the TP button moves the admin to the selected player's live position. Refresh fetches current data. Play time uses the player's accumulated server/world `minecraft:play_time` stat; it is not the current login duration.

This repository contains source code and a build workflow, **not a compiled installable JAR**. The GUI and server have not been exercised in a running 1.21.11 instance here.
