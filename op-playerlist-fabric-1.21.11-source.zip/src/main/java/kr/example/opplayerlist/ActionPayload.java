package kr.example.opplayerlist;

import java.util.UUID;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

public record ActionPayload(String action, UUID target) implements CustomPacketPayload {
    public static final Type<ActionPayload> TYPE = new Type<>(Identifier.fromNamespaceAndPath("opplayerlist", "action"));
    public static final StreamCodec<RegistryFriendlyByteBuf, ActionPayload> CODEC = StreamCodec.of(
        (buf, value) -> { buf.writeUtf(value.action(), 16); buf.writeUUID(value.target()); },
        buf -> new ActionPayload(buf.readUtf(16), buf.readUUID())
    );
    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
