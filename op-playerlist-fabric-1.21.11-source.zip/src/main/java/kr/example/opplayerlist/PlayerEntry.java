package kr.example.opplayerlist;

import java.util.UUID;

public record PlayerEntry(UUID uuid, String name, String dimension, int x, int y, int z, long playMinutes) { }
