package kr.example.opplayerlist;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Server sends this only to an authorized operator. */
public record SnapshotPayload(String json) implements CustomPacketPayload {
    public static final Type<SnapshotPayload> TYPE = new Type<>(Identifier.fromNamespaceAndPath("opplayerlist", "snapshot"));
    public static final StreamCodec<RegistryFriendlyByteBuf, SnapshotPayload> CODEC = StreamCodec.of(
        (buf, value) -> buf.writeUtf(value.json(), 262144),
        buf -> new SnapshotPayload(buf.readUtf(262144))
    );
    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
