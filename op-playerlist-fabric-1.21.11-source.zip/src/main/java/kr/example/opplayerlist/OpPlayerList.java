package kr.example.opplayerlist;

import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.permissions.Permissions;
import net.minecraft.stats.Stats;
import static net.minecraft.commands.Commands.literal;

public final class OpPlayerList implements ModInitializer {
    private static final Gson GSON = new Gson();

    private static boolean authorized(ServerPlayer player) {
        return player.permissions().hasPermission(Permissions.COMMANDS_MODERATOR);
    }

    @Override public void onInitialize() {
        PayloadTypeRegistry.playS2C().register(SnapshotPayload.TYPE, SnapshotPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(ActionPayload.TYPE, ActionPayload.CODEC);

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(literal("playerlist")
                .requires(source -> source.permissions().hasPermission(Permissions.COMMANDS_MODERATOR))
                .executes(context -> {
                    ServerPlayer requester = context.getSource().getPlayerOrException();
                    if (authorized(requester)) sendSnapshot(requester);
                    return 1;
                })));

        ServerPlayNetworking.registerGlobalReceiver(ActionPayload.TYPE, (payload, context) ->
            context.server().execute(() -> {
                ServerPlayer requester = context.player();
                if (!authorized(requester)) return;
                if (payload.action().equals("refresh")) {
                    sendSnapshot(requester);
                } else if (payload.action().equals("tp")) {
                    ServerPlayer target = context.server().getPlayerList().getPlayer(payload.target());
                    if (target == null) {
                        requester.sendSystemMessage(Component.literal("해당 플레이어가 접속을 종료했습니다."));
                        sendSnapshot(requester);
                        return;
                    }
                    // The name comes exclusively from the server's online player list.
                    String safeName = target.getGameProfile().name();
                    if (!safeName.matches("[A-Za-z0-9_]{1,16}")) return;
                    context.server().getCommands().performPrefixedCommand(
                        requester.createCommandSourceStack(), "tp " + safeName);
                    sendSnapshot(requester);
                }
            }));
    }

    private static void sendSnapshot(ServerPlayer requester) {
        if (!authorized(requester) || !ServerPlayNetworking.canSend(requester, SnapshotPayload.TYPE)) return;
        List<PlayerEntry> entries = new ArrayList<>();
        for (ServerPlayer player : requester.createCommandSourceStack().getServer().getPlayerList().getPlayers()) {
            long ticks = Math.max(0, player.getStats().getValue(Stats.CUSTOM.get(Stats.PLAY_TIME)));
            entries.add(new PlayerEntry(player.getUUID(), player.getGameProfile().name(),
                player.level().dimension().identifier().toString(), player.blockPosition().getX(),
                player.blockPosition().getY(), player.blockPosition().getZ(), ticks / 1200L));
        }
        entries.sort(Comparator.comparing(PlayerEntry::name, String.CASE_INSENSITIVE_ORDER));
        ServerPlayNetworking.send(requester, new SnapshotPayload(GSON.toJson(entries)));
    }
}
