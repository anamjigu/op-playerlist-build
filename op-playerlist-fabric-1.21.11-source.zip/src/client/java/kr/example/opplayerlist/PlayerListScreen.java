package kr.example.opplayerlist;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.PlayerFaceRenderer;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;

public final class PlayerListScreen extends Screen {
    private static final int PAGE_SIZE = 6;
    private PlayerEntry[] players;
    private EditBox search;
    private final Button[] rows = new Button[PAGE_SIZE];
    private Button previous, next, tp;
    private int page;
    private UUID selected;
    private List<PlayerEntry> filtered = List.of();
    private int left, top, panelWidth;

    public PlayerListScreen(PlayerEntry[] players) {
        super(Component.literal("접속 플레이어"));
        this.players = players;
    }

    public void setPlayers(PlayerEntry[] updated) {
        this.players = updated;
        if (this.search != null) updateRows();
    }

    @Override protected void init() {
        panelWidth = Math.min(370, Math.max(225, width - 24));
        left = (width - panelWidth) / 2;
        top = Math.max(8, (height - 262) / 2);

        search = addRenderableWidget(new EditBox(font, left + 14, top + 31, panelWidth - 28, 18,
            Component.literal("플레이어 이름 검색")));
        search.setHint(Component.literal("닉네임 검색..."));
        search.setResponder(value -> { page = 0; selected = null; updateRows(); });

        for (int i = 0; i < PAGE_SIZE; i++) {
            final int slot = i;
            rows[i] = addRenderableWidget(Button.builder(Component.empty(), button -> select(slot))
                .bounds(left + 42, top + 55 + i * 22, panelWidth - 56, 19).build());
        }
        previous = addRenderableWidget(Button.builder(Component.literal("◀"), button -> {
            page--; updateRows();
        }).bounds(left + 15, top + 191, 34, 19).build());
        next = addRenderableWidget(Button.builder(Component.literal("▶"), button -> {
            page++; updateRows();
        }).bounds(left + panelWidth - 49, top + 191, 34, 19).build());
        addRenderableWidget(Button.builder(Component.literal("새로고침"), button ->
            ClientPlayNetworking.send(new ActionPayload("refresh", new UUID(0, 0))))
            .bounds(left + panelWidth / 2 - 43, top + 191, 86, 19).build());
        tp = addRenderableWidget(Button.builder(Component.literal("선택한 플레이어에게 TP"), button -> {
            if (selected != null) ClientPlayNetworking.send(new ActionPayload("tp", selected));
        }).bounds(left + 14, top + 232, panelWidth - 28, 19).build());

        updateRows();
    }

    private void select(int slot) {
        int index = page * PAGE_SIZE + slot;
        if (index >= filtered.size()) return;
        selected = filtered.get(index).uuid();
        updateRows();
    }

    private void updateRows() {
        if (search == null) return;
        String query = search.getValue().toLowerCase(Locale.ROOT).trim();
        filtered = Arrays.stream(players)
            .filter(p -> p.name().toLowerCase(Locale.ROOT).contains(query)).toList();
        page = Math.max(0, Math.min(page, Math.max(0, (filtered.size() - 1) / PAGE_SIZE)));
        if (selected != null && Arrays.stream(players).noneMatch(p -> p.uuid().equals(selected))) selected = null;
        for (int i = 0; i < PAGE_SIZE; i++) {
            int index = page * PAGE_SIZE + i;
            rows[i].visible = index < filtered.size();
            if (rows[i].visible) {
                PlayerEntry entry = filtered.get(index);
                rows[i].setMessage(Component.literal((entry.uuid().equals(selected) ? "◆ " : "") + entry.name()));
            }
        }
        previous.active = page > 0;
        next.active = (page + 1) * PAGE_SIZE < filtered.size();
        tp.active = selected != null;
    }

    @Override public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        graphics.fill(0, 0, width, height, 0xB6000000);
        graphics.fill(left, top, left + panelWidth, top + 260, 0xF21D2635);
        graphics.fill(left, top, left + panelWidth, top + 3, 0xFF68BDEB);
        graphics.drawString(font, "접속 플레이어 (" + players.length + ")", left + 14, top + 12, 0xFFFFFFFF, true);
        for (int i = 0; i < PAGE_SIZE; i++) {
            int index = page * PAGE_SIZE + i;
            if (index >= filtered.size()) break;
            PlayerEntry p = filtered.get(index);
            graphics.fill(left + 13, top + 56 + i * 22, left + 38, top + 74 + i * 22, 0xFF384A5E);
            if (minecraft != null && minecraft.getConnection() != null) {
                PlayerInfo info = minecraft.getConnection().getPlayerInfo(p.uuid());
                if (info != null) PlayerFaceRenderer.draw(graphics, info.getSkin(), left + 17, top + 57 + i * 22, 16);
            }
        }
        graphics.drawCenteredString(font, (page + 1) + " / " + Math.max(1, (filtered.size() + PAGE_SIZE - 1) / PAGE_SIZE),
            left + panelWidth / 2, top + 180, 0xFFB9C9D9);

        PlayerEntry chosen = selected == null ? null : Arrays.stream(players)
            .filter(p -> p.uuid().equals(selected)).findFirst().orElse(null);
        if (chosen != null) {
            long hours = chosen.playMinutes() / 60;
            long minutes = chosen.playMinutes() % 60;
            graphics.drawString(font, chosen.name() + "  |  " + chosen.dimension(), left + 14, top + 213, 0xFFE2F3FF, false);
            graphics.drawString(font, "좌표 " + chosen.x() + ", " + chosen.y() + ", " + chosen.z()
                + "    플레이 " + hours + "시간 " + minutes + "분", left + 14, top + 224, 0xFFB9C9D9, false);
        } else {
            graphics.drawString(font, "플레이어를 누르면 차원, 좌표, 플레이 시간이 표시됩니다.",
                left + 14, top + 216, 0xFFB9C9D9, false);
        }
        super.render(graphics, mouseX, mouseY, delta);
    }

    @Override public boolean isPauseScreen() { return false; }
}
