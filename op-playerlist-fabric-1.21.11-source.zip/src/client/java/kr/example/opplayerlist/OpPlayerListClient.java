package kr.example.opplayerlist;

import com.google.gson.Gson;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

public final class OpPlayerListClient implements ClientModInitializer {
    private static final Gson GSON = new Gson();

    @Override public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(SnapshotPayload.TYPE, (payload, context) ->
            context.client().execute(() -> {
                PlayerEntry[] players = GSON.fromJson(payload.json(), PlayerEntry[].class);
                if (players == null) return;
                if (context.client().screen instanceof PlayerListScreen screen) screen.setPlayers(players);
                else context.client().setScreen(new PlayerListScreen(players));
            }));
    }
}
